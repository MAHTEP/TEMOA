Examples from "AMPL: A Modeling Language for Mathematical Programming", 
version 2.  Pyomo examples are indicated with *.py files.  SUCASA *.map
files are also included, to validate SUCASA's ability to parse AMPL files.
