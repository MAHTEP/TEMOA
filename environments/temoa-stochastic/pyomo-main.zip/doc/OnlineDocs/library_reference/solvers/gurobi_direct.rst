GurobiDirect
============

.. currentmodule:: pyomo.solvers.plugins.solvers.gurobi_direct

Methods
-------

.. autosummary::

   GurobiDirect.available
   GurobiDirect.close
   GurobiDirect.close_global
   GurobiDirect.solve
   GurobiDirect.version

.. autoclass:: GurobiDirect
   :members: available, close, close_global, solve, version
