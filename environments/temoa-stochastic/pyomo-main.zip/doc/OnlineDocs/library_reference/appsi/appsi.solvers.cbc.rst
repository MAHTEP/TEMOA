Cbc
===

.. autoclass:: pyomo.contrib.appsi.solvers.cbc.CbcConfig
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:
  :exclude-members: NoArgument

.. autoclass:: pyomo.contrib.appsi.solvers.cbc.Cbc
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:
