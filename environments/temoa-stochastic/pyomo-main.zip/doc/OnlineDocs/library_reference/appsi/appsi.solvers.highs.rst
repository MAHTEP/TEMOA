HiGHS
=====

.. autoclass:: pyomo.contrib.appsi.solvers.highs.HighsResults
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:

.. autoclass:: pyomo.contrib.appsi.solvers.highs.Highs
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:
