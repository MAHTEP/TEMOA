Ipopt
=====

.. autoclass:: pyomo.contrib.appsi.solvers.ipopt.IpoptConfig
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:

.. autoclass:: pyomo.contrib.appsi.solvers.ipopt.Ipopt
  :members:
  :inherited-members:
  :undoc-members:
  :show-inheritance:
