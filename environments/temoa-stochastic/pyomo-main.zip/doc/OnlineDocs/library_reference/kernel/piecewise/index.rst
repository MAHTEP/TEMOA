Piecewise Function Library
==========================

Modules

.. toctree::
   :maxdepth: 1

   piecewise.rst
   piecewise_nd.rst
   util.rst
