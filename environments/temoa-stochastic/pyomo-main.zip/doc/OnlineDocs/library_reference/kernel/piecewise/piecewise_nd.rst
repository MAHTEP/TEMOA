Multi-variate Piecewise Functions
=================================

Summary
~~~~~~~
.. autosummary::
   pyomo.core.kernel.piecewise_library.transforms_nd.piecewise_nd
   pyomo.core.kernel.piecewise_library.transforms_nd.PiecewiseLinearFunctionND
   pyomo.core.kernel.piecewise_library.transforms_nd.TransformedPiecewiseLinearFunctionND
   pyomo.core.kernel.piecewise_library.transforms_nd.piecewise_nd_cc

Member Documentation
~~~~~~~~~~~~~~~~~~~~
.. autofunction:: pyomo.core.kernel.piecewise_library.transforms_nd.piecewise_nd
.. autoclass:: pyomo.core.kernel.piecewise_library.transforms_nd.PiecewiseLinearFunctionND
   :show-inheritance:
   :special-members: __call__
   :members:
.. autoclass:: pyomo.core.kernel.piecewise_library.transforms_nd.TransformedPiecewiseLinearFunctionND
   :show-inheritance:
   :special-members: __call__
   :members:
.. autoclass:: pyomo.core.kernel.piecewise_library.transforms_nd.piecewise_nd_cc
   :show-inheritance:
   :members:
