Variables
=========

Summary
~~~~~~~
.. autosummary::

   pyomo.core.kernel.variable.variable
   pyomo.core.kernel.variable.variable_tuple
   pyomo.core.kernel.variable.variable_list
   pyomo.core.kernel.variable.variable_dict

Member Documentation
~~~~~~~~~~~~~~~~~~~~
.. autoclass:: pyomo.core.kernel.variable.variable
   :show-inheritance:
   :members:
.. autoclass:: pyomo.core.kernel.variable.variable_tuple
   :show-inheritance:
   :members:
.. autoclass:: pyomo.core.kernel.variable.variable_list
   :show-inheritance:
   :members:
.. autoclass:: pyomo.core.kernel.variable.variable_dict
   :show-inheritance:
   :members:
