Block Triangularization
=======================

.. automodule:: pyomo.contrib.incidence_analysis.triangularize
   :members:
