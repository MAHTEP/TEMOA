Block Triangular Decomposition Solver
=====================================

.. automodule:: pyomo.contrib.incidence_analysis.scc_solver
   :members:
