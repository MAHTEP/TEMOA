.. _incidence_api:

API Reference
=============

.. toctree::
   incidence.rst
   config.rst
   interface.rst
   matching.rst
   connected.rst
   triangularize.rst
   dulmage_mendelsohn.rst
   scc_solver.rst
