Incident Variables
==================

.. automodule:: pyomo.contrib.incidence_analysis.incidence
   :members:
