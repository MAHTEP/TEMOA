Maximum Matching
================

.. automodule:: pyomo.contrib.incidence_analysis.matching
   :members:
