Dulmage-Mendelsohn Partition
============================

.. automodule:: pyomo.contrib.incidence_analysis.dulmage_mendelsohn
   :members:
