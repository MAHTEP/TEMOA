Examples
========

Please see ``pyomo/contrib/mpc/examples/cstr/run_openloop.py`` and 
``pyomo/contrib/mpc/examples/cstr/run_mpc.py`` for examples of some simple
use cases.
