MPC
===

This package contains data structures and utilities for dynamic optimization
and rolling horizon applications, e.g. model predictive control.

.. toctree::
   :maxdepth: 1

   overview.rst
   examples.rst
   faq.rst
