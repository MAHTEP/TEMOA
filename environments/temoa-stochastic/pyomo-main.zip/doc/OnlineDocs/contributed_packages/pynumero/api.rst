.. _pynumero_api:

PyNumero API
============

.. automodule:: pyomo.contrib.pynumero
    :members:
    :undoc-members:

.. toctree::

   pynumero.sparse
   pynumero.interfaces
   pynumero.linalg
