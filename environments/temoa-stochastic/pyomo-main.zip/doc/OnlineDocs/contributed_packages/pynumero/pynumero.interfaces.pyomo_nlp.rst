Pyomo NLP Interface
===================

.. autoclass:: pyomo.contrib.pynumero.interfaces.pyomo_nlp.PyomoNLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:
