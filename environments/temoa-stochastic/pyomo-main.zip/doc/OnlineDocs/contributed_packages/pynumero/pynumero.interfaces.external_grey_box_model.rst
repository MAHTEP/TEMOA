External Grey Box Model
=======================

.. autoclass:: pyomo.contrib.pynumero.interfaces.external_grey_box.ExternalGreyBoxModel
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:
