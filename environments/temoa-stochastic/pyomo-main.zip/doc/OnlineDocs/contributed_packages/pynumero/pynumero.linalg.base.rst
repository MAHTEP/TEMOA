Linear Solver Base Classes
==========================

.. autoclass:: pyomo.contrib.pynumero.linalg.base.LinearSolverStatus
  :members:
  :inherited-members:
  :show-inheritance:
  :undoc-members:

.. autoclass:: pyomo.contrib.pynumero.linalg.base.LinearSolverResults
  :members:
  :inherited-members:
  :show-inheritance:
  :undoc-members:

.. autoclass:: pyomo.contrib.pynumero.linalg.base.LinearSolverInterface
  :members:
  :inherited-members:
  :show-inheritance:
  :undoc-members:

.. autoclass:: pyomo.contrib.pynumero.linalg.base.DirectLinearSolverInterface
  :members:
  :inherited-members:
  :show-inheritance:
  :undoc-members:
