AMPL NLP Interface
==================

.. autoclass:: pyomo.contrib.pynumero.interfaces.ampl_nlp.AmplNLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:
