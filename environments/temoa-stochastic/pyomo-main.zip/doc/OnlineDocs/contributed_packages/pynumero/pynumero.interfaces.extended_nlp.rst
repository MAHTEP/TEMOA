Extended NLP Interface
======================

.. autoclass:: pyomo.contrib.pynumero.interfaces.nlp.ExtendedNLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:
