PyNumero Linear Solver Interfaces
=================================

.. automodule:: pyomo.contrib.pynumero.linalg
  :members:

.. toctree::

   pynumero.linalg.base
   pynumero.linalg.ma27
   pynumero.linalg.ma57
   pynumero.linalg.mumps
   pynumero.linalg.scipy

