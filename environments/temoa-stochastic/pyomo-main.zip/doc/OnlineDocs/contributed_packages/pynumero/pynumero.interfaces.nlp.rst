NLP Interface
=============

.. autoclass:: pyomo.contrib.pynumero.interfaces.nlp.NLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:
