ASL NLP Interface
=================

.. autoclass:: pyomo.contrib.pynumero.interfaces.ampl_nlp.AslNLP
  :members:
  :undoc-members:
  :inherited-members:
  :show-inheritance:
