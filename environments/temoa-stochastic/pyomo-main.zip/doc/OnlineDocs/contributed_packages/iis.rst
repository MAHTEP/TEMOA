Infeasible Irreducible System (IIS) Tool
========================================

.. automodule:: pyomo.contrib.iis.iis

.. autofunction:: pyomo.contrib.iis.write_iis
