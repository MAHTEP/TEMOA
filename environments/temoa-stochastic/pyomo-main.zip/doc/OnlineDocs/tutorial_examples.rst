Pyomo Tutorial Examples
=======================

Additional Pyomo tutorials and examples can be found at the following links:

`Prof. Jeffrey Kantor's Pyomo Cookbook
<https://jckantor.github.io/ND-Pyomo-Cookbook/>`_

`Pyomo Gallery
<https://github.com/Pyomo/PyomoGallery>`_


