Advanced Topics
===============

.. toctree::
   :maxdepth: 1

   persistent_solvers.rst
   units_container.rst
   linearexpression.rst
   flattener/index.rst
   sos_constraints.rst
