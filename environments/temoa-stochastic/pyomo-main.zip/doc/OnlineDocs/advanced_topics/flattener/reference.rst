API reference
=============

.. autosummary::

   pyomo.dae.flatten.slice_component_along_sets
   pyomo.dae.flatten.flatten_components_along_sets
   pyomo.dae.flatten.flatten_dae_components

.. autofunction:: pyomo.dae.flatten.slice_component_along_sets

.. autofunction:: pyomo.dae.flatten.flatten_components_along_sets

.. autofunction:: pyomo.dae.flatten.flatten_dae_components
