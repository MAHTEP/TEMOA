Modeling Extensions
===================

.. toctree::
   :maxdepth: 1

   bilevel.rst
   dae.rst
   gdp/index.rst
   mpec.rst
   stochastic_programming.rst
   network.rst
