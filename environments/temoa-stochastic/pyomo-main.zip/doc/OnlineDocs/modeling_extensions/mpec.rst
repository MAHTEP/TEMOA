MPEC
====

``pyomo.mpec`` supports modeling complementarity conditions and
optimization problems with equilibrium constraints.

