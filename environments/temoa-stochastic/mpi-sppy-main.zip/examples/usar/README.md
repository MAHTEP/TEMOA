# Urban search and rescue (USAR) example

`extensive_form.py` and `wheel_spinner.py` are the main scripts to be run from the command line. Run either with the `--help` option to show the command-line arguments expected. Unlike `extensive_form.py`, `wheel_spinner.py` is intended to be run in parallel via MPI.
