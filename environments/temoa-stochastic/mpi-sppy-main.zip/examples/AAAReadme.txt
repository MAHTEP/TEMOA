The examples are provided as a starting point for programmers who
want to develop their own code.

Note for developers:

run_all.py is run as a weekly test, so if you are doing
a PR with a new example, be sure to call if from there.
