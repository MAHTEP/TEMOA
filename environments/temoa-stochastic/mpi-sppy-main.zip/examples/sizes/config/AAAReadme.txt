This directory contains three files from PySP; not used directly by
mpi-sppy.
