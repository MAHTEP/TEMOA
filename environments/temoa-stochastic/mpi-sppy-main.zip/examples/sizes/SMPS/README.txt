This is the original set of files from Woodruff for the SIZES SMPS. 
"sizes.mps" is the deterministic equivalent for SIZES10.
"sizes.sto" specifies the scenarios for SIZES10.
