afarmer.py has been deprecated (the functionality is now all in farmer.py)
