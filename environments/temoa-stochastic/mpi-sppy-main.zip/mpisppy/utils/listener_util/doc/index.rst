listener_util
==========

A utility for listener-worker asynchronous python. Develope for
the PH and APH use cases.

.. toctree::
   :maxdepth: 2

   touse.rst
   philosophy.rst
   api.rst

Indices and Tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
