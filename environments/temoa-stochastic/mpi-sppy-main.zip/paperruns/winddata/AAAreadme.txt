created by dlw august 2020

wind scenarios based on CAISO 2014 (the directory with "actuals" in the name has scenarios of 
wind actuals (as opposed to scenarios of wind forecasts, which mape-maker can also create).
There are two days worth of scenarios 

As you will see from the row and column labels, the rows are hours and the columns are scenarios 
(e.g., actuals_n_102 is scenario 102 (zero based)
