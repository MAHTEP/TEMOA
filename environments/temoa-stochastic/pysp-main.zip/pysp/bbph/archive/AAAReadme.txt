Files more-or-less as used for the bbph.py paper;
created by dlw Dec 2016
