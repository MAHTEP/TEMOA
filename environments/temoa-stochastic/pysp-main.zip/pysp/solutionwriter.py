#  ___________________________________________________________________________
#
#  Pyomo: Python Optimization Modeling Objects
#  Copyright 2017 National Technology and Engineering Solutions of Sandia, LLC
#  Under the terms of Contract DE-NA0003525 with National Technology and 
#  Engineering Solutions of Sandia, LLC, the U.S. Government retains certain 
#  rights in this software.
#  This software is distributed under the 3-clause BSD License.
#  ___________________________________________________________________________

__all__ = ['ISolutionWriterExtension']

from pyomo.common.plugin_base import Interface


class ISolutionWriterExtension(Interface):

    def write(self, scenario_tree, output_file_prefix):
        """Called with a ScenarioTree type object."""
        pass
