slack penalty example - what the scenarios want, they really should *want*
with a sharp penalty
see comments in reference model


