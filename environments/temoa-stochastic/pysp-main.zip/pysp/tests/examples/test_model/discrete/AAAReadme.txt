a single variable oscillation example
