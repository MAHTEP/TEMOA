This directory contains pyomo/pysp models and data for a variant of Birge and Louveaux's farmer example in
which the farmer can only plant complete (integral or non-fractional) acres of a particular crop. 

Mainly used for Pyomo testing, in order to provide a very simple mixed-integer program.

