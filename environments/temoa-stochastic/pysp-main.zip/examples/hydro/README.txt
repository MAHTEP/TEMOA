A continuous multi-stage hydro planning problem, courtesy of Claudio Andres Troncoso Malebran. References for the model are as follows:

Thesis: Herramienta docente para estudios de Coordinacion Hidrotermica
Laboratory: Centro de Energia - FCFM

The model is in Spanish, but the intent (once you know it is a hydro model) should be pretty easy to pick up.

Serves as an invaluable case for multi-stage regression tests.
