This directory contains scripts that can be used for the purpose
of driving ph. For example, makephscript.py has hard-coded inputs
and writes a bash script file that can used to run ph in parallel.
