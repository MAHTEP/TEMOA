For lagrangeParam etc.
