This is a variant of farmer in which the crop profit is a quadratic function of the amount sold. 

A completely artificial example - the main intent is to illustrate the use of the Piecewise 
construct in the context of a stochastic program, and to provide the corresponding regression
test case.
