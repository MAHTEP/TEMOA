Bibliography
============

.. [BirgeLouveauxBook] J.R. Birge and F. Louveaux. Introduction to
                        Stochastic Programming. Springer Series in
                        Operations Research. New York. Springer, 1997

.. [PyomoBookII] W. E. Hart, C. D. Laird,
                 J.-P. Watson, D. L. Woodruff, G. A. Hackebeil, B. L. Nicholson, 
                 J. D. Siirola. Pyomo - Optimization Modeling in Python,
                 2nd Edition.  Springer Optimization and Its
                 Applications, Vol 67.  Springer, 2017.

.. [PyomoJournal] William E. Hart, Jean-Paul Watson, David L. Woodruff.
                  "Pyomo: modeling and solving mathematical programs in
                  Python," Mathematical Programming Computation, Volume
                  3, Number 3, August 2011

.. [PySPJournal] Jean-Paul Watson, David L. Woodruff, William E. Hart.
                 "Pyomo: modeling and solving mathematical programs in
                 Python," Mathematical Programming Computation, Volume
                 4, Number 2, June 2012, Pages 109-142
